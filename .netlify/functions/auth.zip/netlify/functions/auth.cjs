var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/auth.js
var auth_exports = {};
__export(auth_exports, {
  config: () => config,
  default: () => auth_default
});
module.exports = __toCommonJS(auth_exports);
var auth_default = async (req) => {
  const { password } = await req.json();
  if (password && password === process.env.DEMO_PASSWORD) {
    return new Response("ok", { status: 200 });
  }
  return new Response("Unauthorized", { status: 401 });
};
var config = { path: "/api/auth" };
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
